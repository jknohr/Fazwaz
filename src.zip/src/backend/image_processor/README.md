# Image Processor

Image validation, conversion and processing.

## Files
analysis_pipeline.rs - Image processing workflow
image_model.rs - Image data structures
validation.rs - Format and size validation 