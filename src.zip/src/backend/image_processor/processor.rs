use std::sync::Arc;
use image::{DynamicImage, ImageFormat};
use webp::Encoder;
use tracing::{info, warn, instrument};

use crate::{
    error::Result,
    trans_storage::file_manager::FileManager,
    monitoring::metrics::ImageMetrics,
};

pub struct ImageProcessor {
    file_manager: Arc<FileManager>,
    metrics: Arc<ImageMetrics>,
    max_size: usize,
    supported_formats: Vec<ImageFormat>,
}

impl ImageProcessor {
    #[instrument(skip(self, data))]
    pub async fn process_image(&self, data: Vec<u8>, filename: &str) -> Result<ProcessedImage> {
        let timer = self.metrics.image_processing_duration.start_timer();
        
        // Validate format and size
        self.validate_image(&data)?;
        
        // Load and process image
        let img = image::load_from_memory(&data)?;
        let processed = self.optimize_image(img)?;
        
        // Convert to WebP
        let webp_data = self.convert_to_webp(&processed)?;
        
        timer.observe_duration();
        Ok(ProcessedImage {
            data: webp_data,
            filename: format!("{}.webp", filename),
            width: processed.width(),
            height: processed.height(),
        })
    }

    // Rest of implementation...
} 