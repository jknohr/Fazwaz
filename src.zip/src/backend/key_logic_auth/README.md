# Key Logic Auth

Authentication and rate limiting.

## Files
auth.rs - Authentication logic
rate_limit.rs - Rate limiting 