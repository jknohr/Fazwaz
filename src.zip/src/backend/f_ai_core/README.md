# F_AI Core

Core system operations and maintenance tasks.

## Files
key_cleanup.rs - Handles expired key cleanup
temp_cleanup.rs - Manages temporary file cleanup 