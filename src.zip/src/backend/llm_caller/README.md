# LLM Caller

OpenAI/LLM integration and batch processing.

## Files
openai_client.rs - OpenAI API client and image analysis
batch_processor.rs - Batch job management
prompt_templates.rs - System prompts
embedding_service.rs - Image embedding generation 