use async_openai::{
    Client,
    config::OpenAIConfig,
    types::{ChatCompletion, ChatCompletionMessage, MessageContent},
};
use serde::{Serialize, Deserialize};
use tracing::{info, instrument};
use base64::{Engine as _, engine::general_purpose::STANDARD as BASE64};

use crate::{
    error::{Result, AppError},
    monitoring::metrics::ImageMetrics,
};

#[derive(Debug, Serialize, Deserialize)]
pub struct ImageAnalysisRequest {
    pub model: String,
    pub messages: Vec<ChatMessage>,
    pub max_tokens: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ChatMessage {
    pub role: String,
    pub content: Vec<MessageContent>,
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum MessageContent {
    #[serde(rename = "text")]
    Text { text: String },
    
    #[serde(rename = "image_url")]
    ImageUrl { 
        image_url: ImageUrl,
    },
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ImageUrl {
    pub url: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub detail: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct RealEstateAnalysis {
    pub description: String,
    pub features: RealEstateFeatures,
    pub condition_score: u8,
    pub suggested_improvements: Vec<String>,
    pub market_insights: MarketInsights,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct RealEstateFeatures {
    pub property_type: String,
    pub room_count: RoomCount,
    pub square_footage: Option<u32>,
    pub key_features: Vec<String>,
    pub amenities: Vec<String>,
    pub style: String,
    pub construction: ConstructionDetails,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct RoomCount {
    pub bedrooms: u32,
    pub bathrooms: f32,
    pub other_rooms: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ConstructionDetails {
    pub materials: Vec<String>,
    pub condition: String,
    pub year_built: Option<u32>,
    pub recent_updates: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct MarketInsights {
    pub target_buyer_profile: Vec<String>,
    pub competitive_advantages: Vec<String>,
    pub suggested_improvements: Vec<String>,
    pub estimated_value_range: Option<ValueRange>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ValueRange {
    pub min: u32,
    pub max: u32,
    pub currency: String,
}

pub struct OpenAIClient {
    client: Client<OpenAIConfig>,
    metrics: Arc<ImageMetrics>,
}

impl OpenAIClient {
    #[instrument(skip(self, image_data))]
    pub async fn analyze_property(&self, image_data: &[u8]) -> Result<RealEstateAnalysis> {
        let timer = self.metrics.openai_request_duration.start_timer();
        
        let base64_image = BASE64.encode(image_data);
        let image_url = format!("data:image/jpeg;base64,{}", base64_image);

        let request = ImageAnalysisRequest {
            model: "gpt-4o-mini".to_string(),
            messages: vec![ChatMessage {
                role: "user".to_string(),
                content: vec![
                    MessageContent::Text { 
                        text: self.real_estate_prompt() 
                    },
                    MessageContent::ImageUrl {
                        image_url: ImageUrl {
                            url: image_url,
                            detail: Some("high".to_string()),
                        }
                    }
                ],
            }],
            max_tokens: Some(2000),
        };

        let response = self.client
            .chat()
            .create(request)
            .await
            .map_err(|e| AppError::ExternalService(format!("OpenAI API error: {}", e)))?;

        timer.observe_duration();
        self.metrics.successful_openai_requests.inc();

        // Parse the structured response
        serde_json::from_str(&response.choices[0].message.content)
            .map_err(|e| AppError::ParseError(format!("Failed to parse OpenAI response: {}", e)))
    }

    fn real_estate_prompt(&self) -> String {
        include_str!("../prompts/real_estate_analysis.txt").to_string()
    }
} 