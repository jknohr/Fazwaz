use std::sync::Arc;
use tokio::sync::mpsc;
use uuid7::Uuid7;
use chrono::{DateTime, Utc};
use serde::{Serialize, Deserialize};
use tracing::{info, instrument};

use crate::{
    error::Result,
    monitoring::metrics::LLMMetrics,
};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LLMBatchJob {
    pub id: String,
    pub batch_id: String,
    pub job_type: LLMJobType,
    pub status: JobStatus,
    pub created_at: DateTime<Utc>,
    pub image_data: Vec<u8>,
    pub attempts: u32,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum LLMJobType {
    ImageAnalysis,
    EmbeddingGeneration,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum JobStatus {
    Pending,
    Processing,
    Completed,
    Failed,
}

pub struct LLMBatchProcessor {
    metrics: Arc<LLMMetrics>,
    max_attempts: u32,
    job_tx: mpsc::Sender<LLMBatchJob>,
} 