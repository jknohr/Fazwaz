// Move from src/services/storage/b2.rs
// This handles B2 storage operations 

use async_trait::async_trait;
use backblaze_b2_client as b2_client;
use b2_client::{
    client::Client as B2Client,
    types::{UploadUrlResponse, UploadFileResponse},
    error::B2Error,
};
use bytes::Bytes;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tracing::{info, warn, instrument};
use uuid7::Uuid7;

use crate::{
    error::{Result, AppError},
    monitoring::metrics::StorageMetrics,
};

#[derive(Debug, Serialize, Deserialize)]
pub struct B2Config {
    pub key_id: String,
    pub key: String,
    pub bucket_id: String,
    pub bucket_name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct B2FileInfo {
    pub file_id: String,
    pub file_name: String,
    pub content_type: String,
    pub content_length: i64,
    pub url: String,
}

pub struct B2Storage {
    client: B2Client,
    bucket_id: String,
    metrics: Arc<StorageMetrics>,
}

impl B2Storage {
    pub async fn new(config: B2Config, metrics: Arc<StorageMetrics>) -> Result<Self> {
        let client = B2Client::new(&config.key_id, &config.key)
            .map_err(|e| AppError::ExternalService(format!("B2 client error: {}", e)))?;

        Ok(Self {
            client,
            bucket_id: config.bucket_id,
            metrics,
        })
    }

    #[instrument(skip(self, data))]
    pub async fn store_file(&self, data: Bytes, filename: &str, content_type: &str) -> Result<B2FileInfo> {
        let timer = self.metrics.storage_operation_duration.start_timer();
        
        let file_name = format!("images/{}/{}", Uuid7::new(), filename);
        info!("Uploading file to B2: {}", file_name);
        
        let upload_auth = self.client
            .get_upload_url(&self.bucket_id)
            .await
            .map_err(|e| AppError::ExternalService(format!("B2 upload auth error: {}", e)))?;

        let upload_result = self.client
            .upload_file(
                &upload_auth,
                &file_name,
                data,
                content_type,
                &[("Content-Type", content_type)],
            )
            .await
            .map_err(|e| AppError::ExternalService(format!("B2 upload error: {}", e)))?;

        timer.observe_duration();
        self.metrics.successful_uploads.inc();

        Ok(B2FileInfo {
            file_id: upload_result.file_id,
            file_name: upload_result.file_name,
            content_type: content_type.to_string(),
            content_length: upload_result.content_length,
            url: format!("{}/file/{}/{}", upload_auth.download_url, self.bucket_id, file_name),
        })
    }

    pub async fn delete_file(&self, file_id: &str) -> Result<()> {
        info!("Deleting file from B2: {}", file_id);
        self.client
            .delete_file_version(file_id, "")
            .await
            .map_err(|e| AppError::ExternalService(format!("B2 delete error: {}", e)))?;
            
        self.metrics.successful_deletions.inc();
        Ok(())
    }
} 