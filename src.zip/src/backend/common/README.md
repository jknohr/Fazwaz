# Common Module

This module contains shared types, utilities, and functionality used across the Neural Reef Registration System.

## Directory Structure
```
common/
├── types/         # Shared data types and structures
├── validation/    # Input validation logic
├── error/        # Error types and handling
└── utils/        # Shared utilities and helpers
```

## Key Components

### Types
Contains core data structures and types used throughout the system:
- Health monitoring types
- Image processing types
- Listing management types
- Authentication types

### Validation
Input validation logic and utilities:
- Image validation (size, format, content)
- Listing data validation
- Request parameter validation

### Error
Centralized error handling:
- Custom error types
- Error conversion traits
- Result type aliases

### Utils
Common utilities and helper functions:
- Pagination helpers
- Rate limiting utilities
- Date/time helpers
- Logging utilities 