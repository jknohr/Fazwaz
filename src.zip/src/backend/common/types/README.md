# Types Module

Core data structures and types used throughout the Neural Reef Registration System.

## Components

### Health Types (`health_types.rs`)
System health monitoring types:
- `SystemStatus` - Overall system health state
- `ComponentStatus` - Individual component health state
- `ComponentHealth` - Health check response structure
- `HealthResponse` - Complete health check response

### Image Types (`image_types.rs`)
Image processing and management types:
- `ImageUploadOptions` - Image upload configuration
- `ImageTransformOptions` - Image transformation parameters
- `BatchProcessingStatus` - Batch operation status tracking
- `ImageSearchQuery` - Image search parameters

### Listing Types (`listing_types.rs`)
Real estate listing management types:
- `ListingId` - Unique listing identifier
- `ListingStatus` - Listing state enumeration
- `CreateListingRequest` - New listing creation parameters
- `UpdateListingRequest` - Listing update parameters

### Auth Types (`auth_types.rs`)
Authentication and authorization types:
- `RateLimit` - API rate limiting configuration
- `ApiKey` - API key structure and metadata
- `CreateKeyRequest` - API key creation parameters 