use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use uuid7::Uuid7;
use anyhow::Result;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ListingId(String);

impl ListingId {
    pub fn new(id: String) -> Result<Self> {
        Ok(Self(id))
    }

    pub fn generate() -> Self {
        Self(Uuid7::now().to_string())
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub enum ListingStatus {
    Draft,
    Active,
    Inactive,
    Archived,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateListingRequest {
    pub listing_id: String,
    pub title: String,
    pub description: String,
    pub price: f64,
    pub bedrooms: u32,
    pub bathrooms: u32,
    pub square_feet: u32,
    pub amenities: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdateListingRequest {
    pub title: Option<String>,
    pub description: Option<String>,
    pub price: Option<f64>,
    pub bedrooms: Option<u32>,
    pub bathrooms: Option<u32>,
    pub square_feet: Option<u32>,
    pub amenities: Option<Vec<String>>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Listing {
    pub id: ListingId,
    pub title: String,
    pub description: String,
    pub price: f64,
    pub bedrooms: u32,
    pub bathrooms: u32,
    pub square_feet: u32,
    pub amenities: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub status: ListingStatus,
} 