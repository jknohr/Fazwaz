use prometheus::{IntCounter, Histogram, register_int_counter, register_histogram};

pub struct StorageMetrics {
    pub storage_operation_duration: Histogram,
    pub successful_uploads: IntCounter,
    pub successful_deletions: IntCounter,
}

impl StorageMetrics {
    pub fn new() -> Self {
        Self {
            storage_operation_duration: register_histogram!(
                "storage_operation_duration_seconds",
                "Time spent on storage operations"
            ).unwrap(),
            successful_uploads: register_int_counter!(
                "storage_successful_uploads_total",
                "Number of successful file uploads"
            ).unwrap(),
            successful_deletions: register_int_counter!(
                "storage_successful_deletions_total", 
                "Number of successful file deletions"
            ).unwrap(),
        }
    }
} 